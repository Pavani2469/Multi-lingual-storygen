import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Components
import Navbar from './components/pages/Navbar';
import ProtectedRoute from './components/pages/ProtectedRoute';

// Pages
import Landing from './components/pages/Landing';
import SignUp from './components/pages/SignUp';
import SignIn from './components/pages/SignIn';
import Home from './components/pages/Home';
import Tool from './components/pages/StoryTool';
import Contact from './components/pages/contact';
import Profile from './components/pages/profile';

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Landing />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/signin" element={<SignIn />} />

        {/* Protected Routes */}
        <Route path="/home" element={
          <ProtectedRoute>
            <Home />
          </ProtectedRoute>
        } />
        <Route path="/tool" element={
          <ProtectedRoute>
            <Tool />
          </ProtectedRoute>
        } />

        {/* Optional: Keep these public or protect later */}
        <Route path="/contact" element={<Contact />} />
        <Route path="/profile" element={<Profile />} />
      </Routes>
    </Router>
  );
}

export default App;
