import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/profile.css';

const Profile = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if user is logged in
    const accessToken = localStorage.getItem('access_token');
    const userEmail = localStorage.getItem('user_email');

    if (!accessToken) {
      // If no token, redirect to signin
      navigate('/signin');
      return;
    }

    // If we have stored user data, use it
    const userData = localStorage.getItem('user');
    if (userData && userData !== 'undefined' && userData !== 'null') {
      try {
        const parsedUser = JSON.parse(userData);
        setUser(parsedUser);
      } catch (error) {
        console.error('Error parsing user data:', error);
        setUser(null);
      }
    } else if (userEmail) {
      // If we only have email (from current backend), create a basic user object
      setUser({
        fullName: 'User', // Default name since we don't have it
        email: userEmail
      });
    } else {
      // No user data available, redirect to signin
      navigate('/signin');
      return;
    }

    setLoading(false);
  }, [navigate]);

  const handleSignOut = () => {
    // Clear all stored data
    localStorage.clear();
    // Redirect to signin page
    navigate('/signin');
  };

  if (loading) {
    return (
      <div className="profile-container">
        <div>Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="profile-container">
        <div>User not found. Please sign in again.</div>
      </div>
    );
  }

  // Format the member since date
  const getMemberSinceDate = () => {
    const currentDate = new Date();
    return currentDate.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long' 
    });
  };

  return (
    <div className="profile-container">
      <h2 className="profile-title">My Profile</h2>
      <div className="profile-box">
        <p><strong>Name:</strong> {user.fullName || 'Not available'}</p>
        <p><strong>Email:</strong> {user.email}</p>
        <p><strong>Member since:</strong> {getMemberSinceDate()}</p>
        
        <div className="profile-actions">
          <button 
            onClick={handleSignOut}
            className="signout-button"
          >
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
};

export default Profile;
// The code is correct as long as the user object is stored in localStorage by SignIn.jsx