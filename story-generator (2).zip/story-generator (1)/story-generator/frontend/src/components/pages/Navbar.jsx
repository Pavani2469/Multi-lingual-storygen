import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../styles/navbar.css';

const Navbar = () => {
  const navigate = useNavigate();
  const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";

  const handleSignOut = () => {
    localStorage.removeItem("isLoggedIn");
    navigate("/");
    window.location.reload();
  };

  // Conditional class for disabling links
  const getLinkClass = (enabled) =>
    enabled ? "nav-link" : "nav-link disabled-link";

  return (
    <nav className="navbar">
      <div className="navbar-logo">AI Story Generator</div>
      <div className="navbar-links">
        <Link to="/" className="nav-link">Landing</Link>
        <Link to="/home" className={getLinkClass(isLoggedIn)}>Home</Link>
        <Link to="/tool" className={getLinkClass(isLoggedIn)}>Tool</Link>
        <Link to="/contact" className={getLinkClass(isLoggedIn)}>Contact</Link>
        <Link to="/profile" className={getLinkClass(isLoggedIn)}>Profile</Link>

        {isLoggedIn ? (
          <button onClick={handleSignOut} className="nav-link signout-btn">Sign Out</button>
        ) : (
          <>
            <Link to="/signin" className="nav-link">Sign In</Link>
            <Link to="/signup" className="nav-link">Sign Up</Link>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
