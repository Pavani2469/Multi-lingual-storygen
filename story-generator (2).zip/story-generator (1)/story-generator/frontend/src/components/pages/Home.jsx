import React from 'react';
import '../styles/home.css';
import '../styles/common.css';

const Home = () => {
  return (
    <div className="home-container">
      <header className="home-header">
        <h2 className="home-title">Welcome to StoryGen AI</h2>
        <p className="home-description">
          Enter a world where imagination meets intelligence. With just a few words, watch your thoughts transform into engaging, original stories powered by cutting-edge AI.
        </p>
      </header>

      <main>
        <section className="home-section">
          <h3>🚀 What You Can Do</h3>
          <ul>
            <li>📝 Input your own custom prompt to guide the story</li>
            <li>🎯 Choose from genres like Horror, Fantasy, Sci-Fi, and more</li>
            <li>🔢 Define the word count for your story</li>
            <li>📖 Instantly generate rich, AI-crafted narratives</li>
            <li>🔊 Listen to your stories with voice narration</li>
          </ul>
        </section>

        <section className="home-section">
          <h3>👤 Personalized Experience</h3>
          <p>
            Sign in to save your stories, track your creative journey, and pick up right where you left off. Your stories are just a click away—anytime, anywhere.
          </p>
        </section>

        <section className="home-section">
          <h3>🌐 Seamless Across Devices</h3>
          <p>
            Whether you're on desktop, tablet, or mobile, StoryGen AI delivers a smooth experience so you can write and explore stories from anywhere.
          </p>
        </section>
      </main>

      <footer className="home-footer">
        <p>
          Need assistance? Visit our <a href="/contact">Contact</a> page or explore the FAQ section.
        </p>
      </footer>
    </div>
  );
};

export default Home;
