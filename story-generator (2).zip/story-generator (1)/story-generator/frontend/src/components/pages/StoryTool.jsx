import React, { useState } from 'react';
import '../styles/storytool.css';

const StoryTool = () => {
  const [keywords, setKeywords] = useState('');
  const [genre, setGenre] = useState('');
  const [wordCount, setWordCount] = useState(200); // Added word count state
  const [story, setStory] = useState('');
  const [loading, setLoading] = useState(false);

  const generateStory = async () => {
    if (!keywords || !genre) {
      alert('Please enter keywords and select a genre.');
      return;
    }

    setLoading(true);
    try {
      // Fixed: Correct endpoint and request format
      const response = await fetch('http://127.0.0.1:8000/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          keywords, 
          genre, 
          word_count: wordCount 
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        setStory(data.story);
      } else {
        setStory(data.story || '⚠️ Failed to generate story. Please try again.');
      }
    } catch (error) {
      setStory('⚠️ Failed to connect to the server. Make sure the backend is running on http://127.0.0.1:8000');
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="storytool-container">
      <h2 className="storytool-title">✨ Generate a Story from Your Imagination!</h2>

      <input
        type="text"
        value={keywords}
        onChange={(e) => setKeywords(e.target.value)}
        placeholder="e.g. A boy is walking in the forest"
        className="storytool-input"
      />

      <select
        value={genre}
        onChange={(e) => setGenre(e.target.value)}
        className="storytool-select"
      >
        <option value="">🎬 Select Genre</option>
        <option value="Adventure">Adventure</option>
        <option value="Fantasy">Fantasy</option>
        <option value="Science Fiction">Science Fiction</option>
        <option value="Mystery">Mystery</option>
        <option value="Thriller">Thriller</option>
        <option value="Horror">Horror</option>
        <option value="Drama">Drama</option>
        <option value="Romance">Romance</option>
        <option value="Comedy">Comedy</option>
        <option value="Crime">Crime</option>
        <option value="Historical Fiction">Historical Fiction</option>
        <option value="Mythology">Mythology</option>
        <option value="Paranormal">Paranormal</option>
        <option value="Superhero">Superhero</option>
        <option value="Post-Apocalyptic">Post-Apocalyptic</option>
      </select>

      {/* Added word count input */}
      <div className="word-count-container">
        <label htmlFor="wordCount">📝 Target Word Count: {wordCount}</label>
        <input
          type="range"
          id="wordCount"
          min="50"
          max="1000"
          value={wordCount}
          onChange={(e) => setWordCount(parseInt(e.target.value))}
          className="word-count-slider"
        />
      </div>

      <button
        onClick={generateStory}
        className="storytool-button"
        disabled={loading}
      >
        {loading ? 'Generating...' : '🚀 Generate Story'}
      </button>

      <div className="feature-section">
        <div className="feature-card">🎭 Choose Your Genre</div>
        <div className="feature-card">🧠 AI-Powered Creativity</div>
        <div className="feature-card">📏 Custom Length</div>
      </div>

      {story && (
        <div className="story-output">
          <h3>📖 Your Generated Story:</h3>
          <p>{story}</p>
        </div>
      )}
    </div>
  );
};

export default StoryTool;