import React from 'react';
import '../styles/example.css';

const Example = () => {
  return (
    <div className="example-container">
      {/* ...content... */}
    </div>
  );
};

export default Example;
