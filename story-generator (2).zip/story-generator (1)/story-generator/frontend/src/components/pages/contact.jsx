import React, { useState } from 'react';
import '../styles/contact.css';

const Contact = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name || !email || !message) {
      setStatus('⚠️ Please fill in all fields.');
      return;
    }

    try {
      const response = await fetch('http://127.0.0.1:8000/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, email, message }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setStatus('✅ Message sent! Thank you for contacting us.');
        setName('');
        setEmail('');
        setMessage('');
      } else {
        setStatus('❌ Failed to send message. Try again later.');
      }
    } catch (error) {
      setStatus('❌ Error contacting server. Please try again.');
    }
  };

  return (
    <div className="contact-container">
      <h2 className="contact-title">Contact Us</h2>
      <form className="contact-form" onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Your Name"
          value={name}
          onChange={e => setName(e.target.value)}
        />
        <input
          type="email"
          placeholder="Your Email"
          value={email}
          onChange={e => setEmail(e.target.value)}
        />
        <textarea
          placeholder="Your Message"
          value={message}
          onChange={e => setMessage(e.target.value)}
        ></textarea>
        <button type="submit">Send Message</button>
        {status && <div style={{ marginTop: '10px', color: status.startsWith('✅') ? 'green' : 'red' }}>{status}</div>}
      </form>
    </div>
  );
};

export default Contact;
