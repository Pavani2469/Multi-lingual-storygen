import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/landing.css';
import '../styles/common.css';

const Landing = () => {
  return (
    <div className="landing-container">
      <header className="landing-header">
        <h1 className="landing-title">Unleash Your Imagination</h1>
        <p className="landing-subtitle">
          Turn your ideas into magical stories using the power of AI.
        </p>
        <div className="landing-actions">
          <Link to="/signup" className="landing-get-started">
            Get Started
          </Link>
          <div className="landing-signin-link">
            Already have an account? <Link to="/signin">Sign In</Link>
          </div>
        </div>
      </header>

      <main>
        <section className="landing-features">
          <h2>Why Choose StoryGen AI?</h2>
          <ul>
            <li>✨ Instantly generate creative, genre-based stories</li>
            <li>🔊 Hear your story with built-in voice narration</li>
            <li>🧠 Powered by cutting-edge AI (FLAN-T5 Large)</li>
            <li>💾 Save and revisit your stories anytime</li>
            <li>📱 Use it on desktop, tablet, or mobile</li>
          </ul>
        </section>

        <section className="landing-description">
          <p>
            Whether you're a student, educator, creator, or storytelling enthusiast,
            <strong> StoryGen AI </strong> brings your imagination to life.
            Just type a prompt, choose your favorite genre, and get a unique story within seconds.
          </p>
          <p>
            Join a growing community of dreamers and creators. Let every idea become a new adventure.
          </p>
        </section>
      </main>

      <footer className="landing-footer">
        <p>&copy; {new Date().getFullYear()} StoryGen AI. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Landing;
