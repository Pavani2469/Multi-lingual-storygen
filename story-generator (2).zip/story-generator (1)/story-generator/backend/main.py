from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel, EmailStr
from transformers import T5Tokenizer, T5ForConditionalGeneration
from fastapi.middleware.cors import CORSMiddleware
import torch
from pymongo import MongoClient
from passlib.context import CryptContext
from datetime import datetime, timedelta
from jose import JWTError, jwt
from typing import Optional
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI()

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# MongoDB connection
MONGODB_URL = "mongodb://localhost:27017"
client = MongoClient(MONGODB_URL)
db = client["story_generator"]
users_collection = db["users"]

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT settings
SECRET_KEY = "your-secret-key-here"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Gmail SMTP Configuration
GMAIL_USERNAME = os.getenv("GMAIL_USERNAME")
GMAIL_PASSWORD = os.getenv("GMAIL_APP_PASSWORD")
ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "admin@yourcompany.com")
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

# Load AI model
model_name = "google/flan-t5-large"
tokenizer = T5Tokenizer.from_pretrained(model_name)
model = T5ForConditionalGeneration.from_pretrained(model_name)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device).half() if torch.cuda.is_available() else model.to(device)

# Pydantic models
class UserSignUp(BaseModel):
    fullName: str
    email: EmailStr
    password: str

class UserSignIn(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    fullName: str
    email: str

class Token(BaseModel):
    access_token: str
    token_type: str
    user: UserResponse

class StoryRequest(BaseModel):
    keywords: str
    genre: str
    word_count: int = 1000

class ContactMessage(BaseModel):
    name: str
    email: str
    message: str

# Helper functions
def hash_password(password: str):
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str):
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def get_user_by_email(email: str):
    return users_collection.find_one({"email": email})

def send_email_to_admin(contact_msg: ContactMessage):
    try:
        msg = MIMEMultipart()
        msg['From'] = GMAIL_USERNAME
        msg['To'] = ADMIN_EMAIL
        msg['Subject'] = f"New Contact Form Message from {contact_msg.name}"
        body = f"""
        Name: {contact_msg.name}
        Email: {contact_msg.email}
        Message: {contact_msg.message}
        Sent at: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC
        """
        msg.attach(MIMEText(body, 'plain'))
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(GMAIL_USERNAME, GMAIL_PASSWORD)
        server.sendmail(GMAIL_USERNAME, ADMIN_EMAIL, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        logger.error(f"Failed to send email: {str(e)}")
        return False

def send_confirmation_email(contact_msg: ContactMessage):
    try:
        msg = MIMEMultipart()
        msg['From'] = GMAIL_USERNAME
        msg['To'] = contact_msg.email
        msg['Subject'] = "Thank you for contacting us!"
        body = f"""
        Dear {contact_msg.name},
        Thank you for reaching out! We have received your message:
        \"{contact_msg.message}\"
        Best regards,\nStory Generator Team
        """
        msg.attach(MIMEText(body, 'plain'))
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(GMAIL_USERNAME, GMAIL_PASSWORD)
        server.sendmail(GMAIL_USERNAME, contact_msg.email, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        logger.error(f"Failed to send confirmation email: {str(e)}")
        return False

# Auth endpoints
@app.post("/signup")
async def signup(user: UserSignUp):
    if get_user_by_email(user.email):
        raise HTTPException(status_code=400, detail="Email already registered")
    user_doc = {
        "fullName": user.fullName,
        "email": user.email,
        "password": hash_password(user.password),
        "created_at": datetime.utcnow()
    }
    result = users_collection.insert_one(user_doc)
    if result.inserted_id:
        return {"message": "Account created successfully!", "success": True}
    raise HTTPException(status_code=500, detail="Failed to create account")

@app.post("/signin", response_model=Token)
async def signin(user: UserSignIn):
    db_user = get_user_by_email(user.email)
    if not db_user or not verify_password(user.password, db_user["password"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    token = create_access_token(data={"sub": user.email}, expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "fullName": db_user["fullName"],
            "email": db_user["email"]
        }
    }

# Story generation
@app.post("/generate")
async def generate(request: StoryRequest):
    try:
        prompt = f"Write a detailed and creative {request.genre} story based on: {request.keywords}. Make it approximately {request.word_count} words."
        input_ids = tokenizer(prompt, return_tensors="pt", truncation=True, padding=True).input_ids.to(device)
        with torch.no_grad():
            output_ids = model.generate(
                input_ids,
                max_length=1600,
                min_length=800,
                temperature=0.9,
                top_p=0.92,
                repetition_penalty=1.2,
                do_sample=True,
                pad_token_id=tokenizer.eos_token_id,
                num_return_sequences=1
            )
        story = tokenizer.decode(output_ids[0], skip_special_tokens=True)
        return {"story": story.replace(prompt, "").strip(), "success": True}
    except Exception as e:
        return {"story": "Sorry, an error occurred.", "success": False, "error": str(e)}

@app.post("/contact")
async def contact(msg: ContactMessage):
    if not GMAIL_USERNAME or not GMAIL_PASSWORD:
        return {"success": True, "message": "Email not configured"}
    admin_email_sent = send_email_to_admin(msg)
    user_email_sent = send_confirmation_email(msg)
    return {
        "success": admin_email_sent,
        "message": "Message processed.",
        "confirmation_sent": user_email_sent
    }

@app.get("/")
async def root():
    return {"message": "Story Generator API is running!"}

@app.get("/test-db")
async def test_db():
    try:
        client.admin.command('ping')
        return {"message": "MongoDB connection successful!"}
    except Exception as e:
        return {"message": f"MongoDB connection failed: {str(e)}"}

@app.get("/test-email")
async def test_email():
    if not GMAIL_USERNAME or not GMAIL_PASSWORD:
        return {"configured": False, "message": "Gmail credentials not set."}
    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(GMAIL_USERNAME, GMAIL_PASSWORD)
        server.quit()
        return {"configured": True, "message": "SMTP connected!"}
    except Exception as e:
        return {"configured": False, "message": str(e)}
